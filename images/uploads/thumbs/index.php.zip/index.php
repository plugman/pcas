<?php
die("Access Denied");
?>
